package com.unimoni.searchdoctors.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.unimoni.searchdoctors.entity.ListsDoctors;

//public interface SearchDoctorRepository extends CrudRepository<ListsDoctors, Long>{
public interface SearchDoctorRepository extends JpaRepository<ListsDoctors, Long>{

	ListsDoctors findByLocationAndSpecialist(String location, String specialist);
}
