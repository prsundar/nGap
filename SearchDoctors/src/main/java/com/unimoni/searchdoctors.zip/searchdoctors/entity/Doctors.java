package com.unimoni.searchdoctors.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
public class Doctors {

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long ID;
	
	@NotBlank
	@NotEmpty
	@NotNull
	@Size(min = 1, max = 60, message = "{EV100}")
	private String location;
	@NotBlank
	@NotEmpty
	@NotNull
	private String specialist;
	
	@JsonIgnore
	private String hospitalName;
	@JsonIgnore
	private String dName;
	
	private int morningStartTimeSlot;
	private int morningEndTimeSlot;
	private int morningTimeGap;
	
	private int noonStartTimeSlot;
	private int noonEndTimeSlot;
	private int noonTimeGap;
	
	private int nightStartTimeSlot;
	private int nightEndTimeSlot;
	private int nightTimeGap;
	
	private Date createdOn;
	
	
	public Doctors() {
		super();
		// TODO Auto-generated constructor stub
	}
		

	public Doctors(long iD,
			@NotBlank @NotEmpty @NotNull @Size(min = 1, max = 60, message = "{EV100}") String location,
			@NotBlank @NotEmpty @NotNull String specialist, String hospitalName, String dName, Date createdOn,int morningStartTimeSlot,
			int morningEndTimeSlot, int morningTimeGap, int noonStartTimeSlot, int noonEndTimeSlot, int noonTimeGap, 
			int nightStartTimeSlot, int nightEndTimeSlot, int nightTimeGap) {
		super();
		ID = iD;
		this.location = location;
		this.specialist = specialist;
		this.hospitalName = hospitalName;
		this.dName = dName;
		this.createdOn = createdOn;
		this.morningStartTimeSlot = morningStartTimeSlot;
		this.morningEndTimeSlot = morningEndTimeSlot;
		this.morningTimeGap = morningTimeGap;
		this.noonStartTimeSlot = noonStartTimeSlot;
		this.noonEndTimeSlot = noonEndTimeSlot;
		this.noonTimeGap = noonTimeGap;
		this.nightStartTimeSlot = nightStartTimeSlot;
		this.nightEndTimeSlot = nightEndTimeSlot;
		this.nightTimeGap = nightTimeGap;
	}


	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	public String getSpecialist() {
		return specialist;
	}
	public void setSpecialist(String specialist) {
		this.specialist = specialist;
	}
	
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	
	public String getdName() {
		return dName;
	}
	public void setdName(String dName) {
		this.dName = dName;
	}


	public long getID() {
		return ID;
	}
	public void setID(long iD) {
		ID = iD;
	}


	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}


	public int getMorningStartTimeSlot() {
		return morningStartTimeSlot;
	}
	public void setMorningStartTimeSlot(int morningStartTimeSlot) {
		this.morningStartTimeSlot = morningStartTimeSlot;
	}
	public int getMorningEndTimeSlot() {
		return morningEndTimeSlot;
	}
	public void setMorningEndTimeSlot(int morningEndTimeSlot) {
		this.morningEndTimeSlot = morningEndTimeSlot;
	}
	public int getMorningTimeGap() {
		return morningTimeGap;
	}
	public void setMorningTimeGap(int morningTimeGap) {
		this.morningTimeGap = morningTimeGap;
	}



	public int getNoonStartTimeSlot() {
		return noonStartTimeSlot;
	}
	public void setNoonStartTimeSlot(int noonStartTimeSlot) {
		this.noonStartTimeSlot = noonStartTimeSlot;
	}
	public int getNoonEndTimeSlot() {
		return noonEndTimeSlot;
	}
	public void setNoonEndTimeSlot(int noonEndTimeSlot) {
		this.noonEndTimeSlot = noonEndTimeSlot;
	}
	public int getNoonTimeGap() {
		return noonTimeGap;
	}
	public void setNoonTimeGap(int noonTimeGap) {
		this.noonTimeGap = noonTimeGap;
	}


	public int getNightStartTimeSlot() {
		return nightStartTimeSlot;
	}
	public void setNightStartTimeSlot(int nightStartTimeSlot) {
		this.nightStartTimeSlot = nightStartTimeSlot;
	}
	public int getNightEndTimeSlot() {
		return nightEndTimeSlot;
	}
	public void setNightEndTimeSlot(int nightEndTimeSlot) {
		this.nightEndTimeSlot = nightEndTimeSlot;
	}
	public int getNightTimeGap() {
		return nightTimeGap;
	}
	public void setNightTimeGap(int nightTimeGap) {
		this.nightTimeGap = nightTimeGap;
	}
	
}
